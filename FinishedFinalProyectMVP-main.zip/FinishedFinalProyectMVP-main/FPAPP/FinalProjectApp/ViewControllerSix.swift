//
//  ViewControllerSix.swift
//  FInalProjectApp
//
//  Created by Saige Forbes on 7/31/21.
//

import UIKit

class ViewControllerSix: UIViewController {

    @IBOutlet weak var questionLabelVC6: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func producPressed(_ sender: UIButton) {
    }
    
    @IBAction func habitsPressed(_ sender: UIButton) {
    }
    
    @IBAction func dailyRoutinesPressed(_ sender: UIButton) {
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
