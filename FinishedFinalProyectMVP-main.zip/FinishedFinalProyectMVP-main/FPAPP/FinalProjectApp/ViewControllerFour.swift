//
//  ViewControllerFour.swift
//  FInalProjectApp
//
//  Created by Saige Forbes on 7/31/21.
//

import UIKit

class ViewControllerFour: UIViewController {

    @IBOutlet weak var questionLabelThree: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func englishButtonPressed(_ sender: UIButton) {
        
    }
    
    @IBAction func chineseButtonPressed(_ sender: UIButton) {
        
    }
    
    
    @IBAction func spanishButtonPressed(_ sender: UIButton) {
        
    }
    
    
    @IBAction func frenchButtonPressed(_ sender: UIButton) {
        
    }
    
    @IBAction func korenButtonPressed(_ sender: UIButton) {
        
    }
    
    @IBAction func germanButtonPressed(_ sender: UIButton) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
